import os
from ament_index_python.packages import get_package_share_directory

#Launch Pacckages
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    #ctrl
    #motor_sys
    #sp_gen


    #Get the address of the YAML File
    controller_yaml = os.path.join(
    get_package_share_directory('motor_control'),
                                'config',
                                'controller_params.yaml'
                                )

    motor_yaml = os.path.join(
    get_package_share_directory('motor_control'),
                                'config',
                                'dc_motor_params.yaml'
                                )
    
    setpoint_yaml = os.path.join(
    get_package_share_directory('motor_control'),
                                'config',
                                'set_point_params.yaml'
                                )
    

    #Grupo1
    motor_node_1 = Node(name="motor_sys_1",
                       package='motor_control',
                       executable='dc_motor',
                       emulate_tty=True,
                       output='screen',
                       namespace="group1",
                       parameters=[motor_yaml]
                       )
    
    sp_node_1 = Node(name="sp_gen_1",
                       package='motor_control',
                       executable='set_point',
                       emulate_tty=True,
                       output='screen',
                       namespace="group1",
                       parameters=[setpoint_yaml]
                       )
    
    controller_node_1 = Node(name="ctrl_1",
                       package='motor_control',
                       executable='ctrl',
                       emulate_tty=True,
                       output='screen',
                       namespace="group1",
                       parameters=[controller_yaml]
                       )

    #Grupo 2
    motor_node_2 = Node(name="motor_sys_2",
                       package='motor_control',
                       executable='dc_motor',
                       emulate_tty=True,
                       output='screen',
                       namespace="group2",
                       parameters=[motor_yaml]
                       )
    
    sp_node_2 = Node(name="sp_gen_2",
                       package='motor_control',
                       executable='set_point',
                       emulate_tty=True,
                       output='screen',
                       namespace="group2",
                       parameters=[setpoint_yaml]
                       )
    
    controller_node_2 = Node(name="ctrl_2",
                       package='motor_control',
                       executable='ctrl',
                       emulate_tty=True,
                       output='screen',
                       namespace="group2",
                       parameters=[controller_yaml]
                       )
    #Grupo 3                 
    motor_node_3 = Node(name="motor_sys_3",
                       package='motor_control',
                       executable='dc_motor',
                       emulate_tty=True,
                       output='screen',
                       namespace="group3",
                       parameters=[motor_yaml]
                       )
    
    sp_node_3 = Node(name="sp_gen_3",
                    package='motor_control',
                    executable='set_point',
                    emulate_tty=True,
                    output='screen',
                    namespace="group3",
                    parameters=[setpoint_yaml]
                    )

    controller_node_3 = Node(name="ctrl_3",
                       package='motor_control',
                       executable='ctrl',
                       emulate_tty=True,
                       output='screen',
                       namespace="group3",
                       parameters=[controller_yaml]
                        )
    l_d = LaunchDescription([motor_node_1, sp_node_1,controller_node_1, motor_node_2, sp_node_2,controller_node_2,motor_node_3, sp_node_3,controller_node_3])

    return l_d