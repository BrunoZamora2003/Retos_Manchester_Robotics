#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import numpy as np
from rcl_interfaces.msg import SetParametersResult

class Controller(Node):
    def __init__(self):
        super().__init__('ctrl')

        # Declarar parámetros del controlador
        self.declare_parameter('Kp', 0.64)
        self.declare_parameter('Ki', 1.8)
        self.declare_parameter('Kd', 0.0)
        self.declare_parameter('sample_time', 0.09)
        # Límite de saturación de la señal de control
        self.declare_parameter('control_sat', 5.0)  
        # Activar o no el anti-windup
        self.declare_parameter('enable_antiwindup', True)

        # Cargar valores de parámetros
        self.Kp = self.get_parameter('Kp').value
        self.Ki = self.get_parameter('Ki').value
        self.Kd = self.get_parameter('Kd').value
        self.sample_time = self.get_parameter('sample_time').value
        self.control_sat = self.get_parameter('control_sat').value
        self.enable_antiwindup = self.get_parameter('enable_antiwindup').value

        # Variables internas
        self.previous_error = 0.0
        self.integral = 0.0
        self.current_set_point = 0.0
        self.current_output = 0.0

        # Publicador de la señal de control
        self.control_pub = self.create_publisher(Float32, 'motor_input_u', 10)

        # Suscriptores
        self.create_subscription(Float32, 'set_point', self.set_point_callback, 10)
        self.create_subscription(Float32, 'motor_output_y', self.motor_output_callback, 10)

        # Timer para ejecución periódica
        self.timer = self.create_timer(self.sample_time, self.timer_callback)

        # Callback para reconfiguración de parámetros en tiempo real
        self.add_on_set_parameters_callback(self.parameter_update_callback)

        self.get_logger().info("Controller node with saturation & anti-windup started.")

    def set_point_callback(self, msg: Float32):
        self.current_set_point = msg.data

    def motor_output_callback(self, msg: Float32):
        self.current_output = msg.data

    def timer_callback(self):
        # Calcular el error
        error = self.current_set_point - self.current_output

        # Parte integral
        self.integral += error * self.sample_time

        # Derivada
        derivative = (error - self.previous_error) / self.sample_time

        # Ley PID ideal
        control_signal = self.Kp * error + self.Ki * self.integral + self.Kd * derivative

        # Aplicar saturación
        if control_signal > self.control_sat:
            control_saturated = self.control_sat
            # Anti-windup
            if self.enable_antiwindup:
                # Revertir la acumulación integral
                self.integral -= error * self.sample_time
        elif control_signal < -self.control_sat:
            control_saturated = -self.control_sat
            # Anti-windup
            if self.enable_antiwindup:
                self.integral -= error * self.sample_time
        else:
            control_saturated = control_signal

        # Guardar error actual
        self.previous_error = error

        # Publicar la señal de control
        msg_out = Float32()
        msg_out.data = control_saturated
        self.control_pub.publish(msg_out)

    def parameter_update_callback(self, params):
        """Callback para actualizar parámetros con rqt_reconfigure."""
        result = SetParametersResult()
        result.successful = True

        for param in params:
            if param.name == "Kp":
                if param.value < 0.0:
                    self.get_logger().warn("Kp must be >= 0")
                    result.successful = False
                    result.reason = "Invalid Kp"
                else:
                    self.Kp = param.value

            elif param.name == "Ki":
                if param.value < 0.0:
                    self.get_logger().warn("Ki must be >= 0")
                    result.successful = False
                    result.reason = "Invalid Ki"
                else:
                    self.Ki = param.value

            elif param.name == "Kd":
                if param.value < 0.0:
                    self.get_logger().warn("Kd must be >= 0")
                    result.successful = False
                    result.reason = "Invalid Kd"
                else:
                    self.Kd = param.value

            elif param.name == "sample_time":
                if param.value <= 0.0:
                    self.get_logger().warn("sample_time must be > 0")
                    result.successful = False
                    result.reason = "Invalid sample_time"
                else:
                    self.sample_time = param.value
                    self.timer.cancel()
                    self.timer = self.create_timer(self.sample_time, self.timer_callback)

            elif param.name == "control_sat":
                if param.value <= 0.0:
                    self.get_logger().warn("control_sat must be > 0")
                    result.successful = False
                    result.reason = "Invalid control_sat"
                else:
                    self.control_sat = param.value

            elif param.name == "enable_antiwindup":
                self.enable_antiwindup = bool(param.value)

        return result

def main(args=None):
    rclpy.init(args=args)
    node = Controller()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
