#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
from std_msgs.msg import Float32
from custom_interfaces.srv import SetProcessBool
from rcl_interfaces.msg import SetParametersResult

class SetPointPublisher(Node):
    def __init__(self):
        super().__init__('sp_gen')

        # Declarar parámetros para la señal
        self.declare_parameter('amplitude', 2.0)
        # Interpretaremos 'omega' como frecuencia en Hz (no rad/s) para todas las señales
        self.declare_parameter('omega', 0.1)
        # Cuatro tipos de señal: 'sin', 'square', 'triangle', 'sawtooth'
        self.declare_parameter('signal_type', 'square')

        # Obtener valores iniciales de parámetros
        self.amplitude = self.get_parameter('amplitude').value
        self.freq = self.get_parameter('omega').value
        self.signal_type = self.get_parameter('signal_type').value

        # Publicador en el tópico "set_point"
        self.signal_publisher = self.create_publisher(Float32, 'set_point', 10)

        # Crear timer para publicar la señal periódicamente
        self.timer_period = 0.1  # segundos
        self.timer = self.create_timer(self.timer_period, self.timer_cb)

        # Cliente del servicio para habilitar el proceso (motor)
        self.cli = self.create_client(SetProcessBool, 'EnableProcess')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Service not available, waiting again...')

        self.signal_msg = Float32()
        self.start_time = self.get_clock().now()
        self.system_running = False

        # Añadimos el callback para actualizar parámetros en tiempo de ejecución
        self.add_on_set_parameters_callback(self.parameter_callback)

        self.get_logger().info("SetPoint Node Started \U0001F680")
        # Enviamos la solicitud para arrancar la simulación (opcional)
        self.send_request(True)

    def timer_cb(self):
        if not self.system_running:
            return

        # Tiempo transcurrido en segundos
        elapsed_time = (self.get_clock().now() - self.start_time).nanoseconds / 1e9

        # Ángulo/fase en radianes, interpretando 'freq' como Hz
        theta = 2.0 * np.pi * self.freq * elapsed_time

        # Generar la señal según el tipo seleccionado
        if self.signal_type == 'sin':
            # Onda senoidal
            self.signal_msg.data = self.amplitude * np.sin(theta)

        elif self.signal_type == 'square':
            # Onda cuadrada
            self.signal_msg.data = self.amplitude * np.sign(np.sin(theta))

        elif self.signal_type == 'triangle':
            # Onda triangular (versión usando arcsin)
            #   triangle(t) ~ (2 / pi) * arcsin(sin(theta))
            self.signal_msg.data = self.amplitude * (2.0 / np.pi) * np.arcsin(np.sin(theta))

        elif self.signal_type == 'sawtooth':
            # Onda diente de sierra
            #   sawtooth(t) ~ 2*( (freq*t) - floor(0.5 + freq*t) )
            # Interpretamos freq como self.freq. 
            # Si prefieres, puedes usar theta/(2*pi) en lugar de freq*t.
            saw_val = 2.0 * ((self.freq * elapsed_time) - np.floor(0.5 + self.freq * elapsed_time))
            self.signal_msg.data = self.amplitude * saw_val

        else:
            # En caso de tipo desconocido, avisamos y usamos sin como fallback
            self.get_logger().warn("Unknown signal type, defaulting to 'sin'")
            self.signal_msg.data = self.amplitude * np.sin(theta)

        # Publicar la señal
        self.signal_publisher.publish(self.signal_msg)

    def send_request(self, enable: bool):
        """ Envía la solicitud al servicio para iniciar/detener el proceso. """
        request = SetProcessBool.Request()
        request.enable = enable

        future = self.cli.call_async(request)
        future.add_done_callback(self.response_callback)

    def response_callback(self, future):
        """ Procesa la respuesta del servicio EnableProcess. """
        try:
            response = future.result()
            if response.success:
                self.system_running = True
                self.get_logger().info(f"Success: {response.message}")
            else:
                self.system_running = False
                self.get_logger().warn(f"Failure: {response.message}")
        except Exception as e:
            self.system_running = False
            self.get_logger().error(f"Service call failed: {e}")

    def parameter_callback(self, params):
        """Callback para actualizar parámetros en tiempo de ejecución (rqt_reconfigure)."""
        successful = True
        reason = ''

        for param in params:
            if param.name == 'amplitude':
                if param.value < 0.0:
                    successful = False
                    reason = "Amplitude cannot be negative"
                    self.get_logger().warn(reason)
                else:
                    self.amplitude = param.value
                    self.get_logger().info(f"Amplitude updated to {self.amplitude}")

            elif param.name == 'omega':
                if param.value < 0.0:
                    successful = False
                    reason = "omega (freq in Hz) cannot be negative"
                    self.get_logger().warn(reason)
                else:
                    self.freq = param.value
                    self.get_logger().info(f"Frequency updated to {self.freq} Hz")

            elif param.name == 'signal_type':
                # Aseguramos que solo se acepten 'sin', 'square', 'triangle', 'sawtooth'
                if param.value not in ['sin', 'square', 'triangle', 'sawtooth']:
                    successful = False
                    reason = "signal_type must be 'sin', 'square', 'triangle' or 'sawtooth'"
                    self.get_logger().warn(reason)
                else:
                    self.signal_type = param.value
                    self.get_logger().info(f"signal_type updated to {self.signal_type}")

        # Retornar el resultado de la reconfiguración
        result = SetParametersResult()
        result.successful = successful
        result.reason = reason
        return result

def main(args=None):
    rclpy.init(args=args)
    node = SetPointPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
